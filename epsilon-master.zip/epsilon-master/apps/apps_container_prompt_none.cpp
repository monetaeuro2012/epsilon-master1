#include "apps_container.h"

const I18n::Message AppsContainer::k_promptMessages[] = {};

const KDColor AppsContainer::k_promptColors[] = {};

const int AppsContainer::k_promptNumberOfMessages = 0;
