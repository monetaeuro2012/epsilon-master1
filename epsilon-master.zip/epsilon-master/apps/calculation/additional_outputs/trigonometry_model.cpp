#include "trigonometry_model.h"

namespace Calculation {

TrigonometryModel::TrigonometryModel() :
  Shared::CurveViewRange(),
  m_angle(NAN)
{
}

}
