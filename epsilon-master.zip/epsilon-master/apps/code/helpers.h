#ifndef CODE_HELPERS_H
#define CODE_HELPERS_H

#include <ion/events.h>

namespace Code {
namespace Helpers {

const char * PythonTextForEvent(Ion::Events::Event event);

}
}

#endif
