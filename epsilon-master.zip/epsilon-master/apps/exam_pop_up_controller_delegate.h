#ifndef APPS_EXAM_POP_UP_CONTROLLER_DELEGATE_H
#define APPS_EXAM_POP_UP_CONTROLLER_DELEGATE_H

class ExamPopUpControllerDelegate {
public:
  virtual void examDeactivatingPopUpIsDismissed() = 0;
};

#endif

