## External App

This folder is a helper to retrieve assembly function that are given as EADK in sample apps.


```bash
make eadk_kernel.s
make eadk_userland.s
```
